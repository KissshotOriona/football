import {Entity, ObjectIdColumn, Column} from "typeorm";
import {IsEmail} from 'class-validator'

@Entity()
export class User {
  @ObjectIdColumn()
  id: number;

  @Column()
  @IsEmail()
  email: string;

  @Column()
  password: string;
}