import { gvars } from 'src/ultils';
const jwt = require('jsonwebtoken');

import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response } from 'express';

@Injectable()
export class CheckAuth implements NestMiddleware {
  use(req: Request, res: Response, next: Function) {
    try {
      const token = req.headers.authorization.split(' ')[1];
      const decode = jwt.verify(token, gvars.JWT_KEY);
      req.app.set("userData", decode);
      next();
    } catch (error) {
      console.log(error);      
      return res.status(401).json({
        message: 'Unauthorized request!',
      });
    }
  }
}
