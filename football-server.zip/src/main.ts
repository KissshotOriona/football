import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from './exception/http-exception.filter';
const bodyParser = require('body-parser');

async function bootstrap() {
  const app = await NestFactory.create(AppModule,{cors: true});
  app.useGlobalFilters(new HttpExceptionFilter());
  app.use(bodyParser.json());
  await app.listen(3200, () => {
    console.log('Server listened on port 3200!');
  });
}
bootstrap();
