import { Injectable } from '@nestjs/common';
import { Repository, getMongoRepository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Team } from 'src/entities/team.entity';
import { UpdateResult, DeleteResult } from 'typeorm';
import { History } from '../entities/history.entity';
import { Match } from 'src/entities/match.entity';
const ObjectId = require('mongodb').ObjectId;
@Injectable()
export class TeamService {
  constructor(
    @InjectRepository(Team)
    private teamRepository: Repository<Team>,
  ) {}

  async findAll(): Promise<Team[]> {
    return await this.teamRepository.find();
  }

  async create(team: Team): Promise<Team> {
    try {
      this.remove();
    } catch (error) {}
    return await this.teamRepository.save(team);
  }
  async insertList(team: Team[]): Promise<Team[]> {
    return await this.teamRepository.save(team);
  }

  async update(team: Team): Promise<UpdateResult> {
    return await this.teamRepository.update(ObjectId(team.id), team);
  }

  async delete(id): Promise<DeleteResult> {
    return await this.teamRepository.delete(id);
  }
  async remove(): Promise<any> {
    getMongoRepository(History).clear();
    getMongoRepository(Match).clear();
    return await this.teamRepository.clear();
  }
  async reCreate(teams: Team): Promise<any> {
    await this.teamRepository.clear();

    return await this.teamRepository.save(teams);
  }

  async updateMatchRes(match): Promise<any> {
    match.isOldOf = match.id;

    const hisRepo = getMongoRepository(History);
    const history = await hisRepo.findOne({ isOldOf: match.isOldOf });

    hisRepo.delete({ isOldOf: match.isOldOf });
    hisRepo.save(match);

    const all = await this.findAll();

    var team1 = all.filter(d => {
      return d.id == match.ids.id1;
    });
    var team2 = all.filter(d => {
      return d.id == match.ids.id2;
    });

    if (typeof history !== 'undefined') {
      let prevTeam1 = team1;
      let prevTeam2 = team2;
      prevTeam1.map(t => (t.mp = t.mp - 1));
      prevTeam2.map(t => (t.mp = t.mp - 1));
      if (history.goal.g1 > history.goal.g2) {
        prevTeam1.map(t => {
          t.gf = t.gf - history.goal.g1;
          t.ga = t.ga - history.goal.g2;
          t.w = t.w - 1;
          t.pts = t.pts - 3;
        });
        prevTeam2.map(t => {
          t.gf = t.gf - history.goal.g2;
          t.ga = t.ga - history.goal.g1;
          t.l = t.l - 1;
        });
      } else {
        if (history.goal.g1 == history.goal.g2) {
          prevTeam1.map(t => {
            t.gf = t.gf - history.goal.g1;
            t.ga = t.ga - history.goal.g2;
            t.d = t.d - 1;
            t.pts = t.pts - 1;
          });
          prevTeam2.map(t => {
            t.gf = t.gf - history.goal.g2;
            t.ga = t.ga - history.goal.g1;
            t.d = t.d - 1;
            t.pts = t.pts - 1;
          });
        } else {
          prevTeam2.map(t => {
            t.gf = t.gf - history.goal.g2;
            t.ga = t.ga - history.goal.g1;
            t.w = t.w - 1;
            t.pts = t.pts - 3;
          });
          prevTeam1.map(t => {
            t.gf = t.gf - history.goal.g1;
            t.ga = t.ga - history.goal.g2;
            t.l = t.l - 1;
          });
        }
      }

      getMongoRepository(Team).update({ stt: team1[0].stt }, prevTeam1[0]);
      getMongoRepository(Team).update({ stt: team2[0].stt }, prevTeam2[0]);
    }

    if (match.goal.g1 > match.goal.g2) {
      team1.map(t => {
        t.gf = t.gf + match.goal.g1;
        t.ga = t.ga + match.goal.g2;
        t.w = t.w + 1;
        t.pts = t.pts + 3;
      });
      team2.map(t => {
        t.gf = t.gf + match.goal.g2;
        t.ga = t.ga + match.goal.g1;
        t.l = t.l + 1;
      });
    } else {
      if (match.goal.g1 == match.goal.g2) {
        team1.map(t => {
          t.gf = t.gf + match.goal.g1;
          t.ga = t.ga + match.goal.g2;
          t.d = t.d + 1;
          t.pts = t.pts + 1;
        });
        team2.map(t => {
          t.gf = t.gf + match.goal.g2;
          t.ga = t.ga + match.goal.g1;
          t.d = t.d + 1;
          t.pts = t.pts + 1;
        });
      } else {
        team2.map(t => {
          t.gf = t.gf + match.goal.g2;
          t.ga = t.ga + match.goal.g1;
          t.w = t.w + 1;
          t.pts = t.pts + 3;
        });
        team1.map(t => {
          t.gf = t.gf + match.goal.g1;
          t.ga = t.ga + match.goal.g2;
          t.l = t.l + 1;
        });
      }
    }

    try {
      team1.map(t => (t.mp = t.mp + 1));
      team2.map(t => (t.mp = t.mp + 1));
      getMongoRepository(Team).update({ stt: team1[0].stt }, team1[0]);
      getMongoRepository(Team).update({ stt: team2[0].stt }, team2[0]);
    } catch (error) {
      console.log(error);
    }
  }
}
