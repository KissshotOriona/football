import { Controller, Get, Post, Body, Res } from '@nestjs/common';
import { MatchService } from './match.service';
import { TeamService } from '../team/team.service';
import { Match } from '../entities/match.entity';

@Controller('match')
export class MatchController {
  constructor(private matchService: MatchService, private teamService: TeamService) {}

  @Get()
  async getAllMatch() {
    return this.matchService.getMatch();
  }

  @Post()
  async updateMatch(@Res() res, @Body() match: Match) {
    this.matchService
      .updateMatch(match)
      .then(data => {
        this.teamService.updateMatchRes(match);
        return res.status(200).json({
          message: 'Match updated!',
        });
      })
      .catch(err => {
        return res.json(500).json({
          message: 'Update error!',
        });
      });
  }
}
