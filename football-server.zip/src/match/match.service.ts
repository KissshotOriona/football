import { Injectable } from '@nestjs/common';
import { Repository, UpdateResult } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Match } from 'src/entities/match.entity';
import { gvars } from 'src/ultils';

@Injectable()
export class MatchService {
  constructor(
    @InjectRepository(Match) private matchRepository: Repository<Match>,
  ) {}

  async getMatch(): Promise<Match[]>{
      return await this.matchRepository.find();
  }

  async createMatch(teams): Promise<any> {
    function addDays(date, days) {
      var result = new Date(date);
      result.setDate(result.getDate() + days);
      return result;
    }
    var match = [];
    
    var date = new Date();
    if (teams.length == 2) {
      match.push({
        ids: { id1: teams[0]['id'], id2: teams[1]['id'] },
        team: { t1: teams[0]['name'], t2: teams[1]['name'] },
        date: gvars.getDateString(date),
        time:
          gvars.time_table[Math.floor(Math.random() * gvars.time_table.length)],
        goal: { g1: 0, g2: 0 },
        card: { y1: 0, y2: 0, r1: 0, r2: 0 },
      });
    } else {
      for (var i = 0; i < teams.length; i++) {
        var t1 = teams[i]['name'];
        var id1 = teams[i]['id'];
        var t2;
        var id2;
        if (i === teams.length - 1) {
          t2 = teams[0]['name'];
          id2 = teams[0]['id'];
        } else {
          t2 = teams[i + 1]['name'];
          id2 = teams[i + 1]['id'];
        }
        match.push({
          ids: { id1: id1, id2: id2 },
          team: { t1: t1, t2: t2 },
          date: gvars.getDateString(date),
          time:
            gvars.time_table[
              Math.floor(Math.random() * gvars.time_table.length)
            ],
          goal: { g1: 0, g2: 0 },
          card: { y1: 0, y2: 0, r1: 0, r2: 0 },
        });

        if (i % 2 == 1) {
          addDays(date, 1);
        }
      }
    }
    return await this.matchRepository.save(match);
  }

  async updateMatch(match): Promise<UpdateResult>{
    return await this.matchRepository.update(match.id, match);
  }
}
