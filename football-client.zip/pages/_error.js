import React from "react";
import "../public/css/error.css";
class Error extends React.Component {
  constructor() {
    super();
    this.genMessage = this.genMessage.bind(this);
  }
  static async getInitialProps({ asPath, res, err }) {
    const statusCode = res ? res.statusCode : err ? err.statusCode : null;
    return { statusCode, asPath };
  }

  genMessage() {
    if (this.props.statusCode) {
      if (this.props.asPath.includes("login")) {
        return "This page is under construction!";
      } else {
        if (this.props.asPath.includes("info")) {
          return "This website is build with react and node js!";
        } else return `An error ${this.props.statusCode} occurred on server`;
      }
    } else {
      return "An error occurred on client";
    }
  }

  render() {
    return (
      <p className="error" style={{ fontSize: "200%" }}>
        {this.genMessage()}
      </p>
    );
  }
}

export default Error;
