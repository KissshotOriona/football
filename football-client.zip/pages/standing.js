import Root from "../components/root/root";
import React, { Component } from "react";
import StandingTable from "../components/standingTable/standingTable";


export class Standing extends Component {
  state = {};
  render() {
    return (
      <Root>
        <StandingTable />
      </Root>
    );
  }
}
export default Standing;
