import React, { Component } from "react";
import TeamForm from "../components/teamForm/teamForm";
import { TeamTable } from "../components/teamTable/teamTable";
import Root from "../components/root/root";

export default class App extends Component {
  constructor(props) {
    super(props);
  }
  static async getInitialProps() {
    try {
      const result = await fetch(process.env.API_HOST + "teams");
      const data = await result.json();
      return {
        teams: data
      };
    } catch (error) {
      console.log(error);
    }
  }
  state = {};
  display = () => {
    if (!this.props.teams.length) {
      return <TeamForm />;
    } else {
      return <TeamTable />;
    }
  };

  render() {
    return <Root>{this.display()}</Root>;
  }
}
