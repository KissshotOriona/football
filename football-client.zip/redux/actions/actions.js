import {
  LOAD_STANDING_DATA,
  LOAD_TEAM_DATA,
  LOAD_MATCH_DATA,
  UPDATE_MATCH_RESULT,
  UPDATE_TEAM_TABLE
} from "../constants/actionTypes";
const api = process.env.API_HOST;

export function getStandingData() {
  return function(dispatch) {
    return fetch(api + "teams")
      .then(res => res.json())
      .then(json => {
        dispatch({ type: LOAD_STANDING_DATA, payload: json });
      });
  };
}

export function getTeamData() {
  return function(dispatch) {
    return fetch(api + "teams")
      .then(res => res.json())
      .then(json => {
        dispatch({ type: LOAD_TEAM_DATA, payload: json });
      });
  };
}

export function updateTable(value) {
  return function(dispatch) {
    dispatch({type: UPDATE_TEAM_TABLE, payload: value});
  };
}


export function getMatchData() {
  return function(dispatch) {
    return fetch(api + "match")
      .then(res => res.json())
      .then(json => {
        dispatch({ type: LOAD_MATCH_DATA, payload: json });
      });
  };
}

export function updateMatchRes(res, index) {
  return function(dispatch) {
    dispatch({
      type: UPDATE_MATCH_RESULT,
      payload: { res: res, index: index }
    });
  };
}

export function postListTeam(data) {
  return function(dispatch) {
    return fetch(api + "teams", {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });
  };
}
