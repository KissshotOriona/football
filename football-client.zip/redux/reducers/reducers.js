import { LOAD_STANDING_DATA, LOAD_TEAM_DATA, LOAD_MATCH_DATA, UPDATE_MATCH_RESULT } from "../constants/actionTypes";

const initialState = {
  teams: [],
  standings: [],
  loaded: 0,
  matchs: []
};

function rootReducer(state = initialState, action) {
  if (action.type === LOAD_STANDING_DATA) {
    return Object.assign({}, state, {
      standings: action.payload,
      loaded: 1
    });
  }
  if (action.type === LOAD_TEAM_DATA) {
    return Object.assign({}, state, {
      teams: action.payload,
      loaded: 1
    });
  }
  if (action.type === LOAD_MATCH_DATA) {
    return Object.assign({}, state, {
      matchs: action.payload,
      loaded: 1
    });
  }
  if (action.type === UPDATE_MATCH_RESULT) {
    let newMatch = state.matchs.filter(d=>{return d.stt == action.payload.index})
    newMatch.res = action.payload.res;
    let oldMatch = state.matchs.filter(d=>{return d.stt != action.payload.index})
    const finalMatch = [...newMatch, ...oldMatch];
    return Object.assign({}, state, {
      matchs: finalMatch
    });
  }
  return state;
}

export default rootReducer;
