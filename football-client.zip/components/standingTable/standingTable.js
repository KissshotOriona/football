import React, { Component } from "react";
import { Table } from "antd";
import { getStandingData } from "../../redux/actions/actions";
import { connect } from "react-redux";

function mapStateToProps(state) {
  return {
    standings: state.standings
  };
}
class StTable extends Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "#",
        dataIndex: "stt",
        width: "5%",
      },
      {
        title: "Name",
        dataIndex: "name",
      },
      {
        title: "MP",
        dataIndex: "mp",
        width: "5%"
      },
      {
        title: "W",
        dataIndex: "w",
        width: "5%"
      },
      {
        title: "D",
        dataIndex: "d",
        width: "5%"
      },
      {
        title: "L",
        dataIndex: "l",
        width: "5%"
      },
      {
        title: "GF",
        dataIndex: "gf",
        width: "5%"
      },
      {
        title: "GA",
        dataIndex: "ga",
        width: "5%"
      },
      {
        title: "GD",
        dataIndex: "gd",
        width: "5%"
      },
      {
        title: "Pts",
        dataIndex: "pts",
        width: "5%",
      }
    ];
  }
  componentDidMount() {
    this.props.getStandingData();
  }
  render() {
    const data = this.props.standings;
    data.map(d => (d.gd = d.gf - d.ga));
    data.sort((a,b)=>{
      if(a.pts>b.pts) return -1;
      if(a.pts<b.pts) return 1;
      return 0;
    })
    return (
      <div>
        <div style={{ marginTop: "10px" }}>
          <p>
            {data.length > 0
              ? ""
              : "*You need to create a league first!"}
          </p>
        </div>
        <Table bordered columns={this.columns} dataSource={data} scroll={{ x: 240 }}/>
      </div>
    );
  }
}
const StandingTable = connect(
  mapStateToProps,
  { getStandingData }
)(StTable);
export default StandingTable;
