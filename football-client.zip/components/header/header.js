import React, { Component } from "react";
import {
  Layout,
  Menu,
  Icon,
  Dropdown,
  Row,
  Col,
  Button
} from "antd";
import "./header.css";
const { Header } = Layout;
import Router from "next/router";
import { connect } from "react-redux";

function mapStateToProps(state) {
  return {
    loaded: state.loaded
  };
}
class HeaderCom extends Component {
  state = {};

  handleClick() {
    Router.push("/");
  }
  render() {
    function handleMenuClick(e) {
      if (e.key == "1") {
        Router.push("/login");
      } else {
        Router.push("/info");
      }
    }

    const menu = (
      <Menu onClick={handleMenuClick}>
        <Menu.Item key="1">
          <Icon type="user" />
          Log out
        </Menu.Item>
        <Menu.Item key="2">
          <Icon type="info-circle" />
          Info
        </Menu.Item>
      </Menu>
    );

    return (
      <Layout>
        <Header
          style={{
            position: "fixed",
            zIndex: 1,
            width: "100%",
            background: "#58a700"
          }}
        >
          <Row>
            <Col span={6}>
              <div className="logo" onClick={this.handleClick}>
                {this.props.loaded == 0 ? <Icon
                  type="loading"
                  style={{
                    position: "absolute",
                    fontSize: "40px",
                    color: "white",
                    top: "10px",
                    left: "-10px"
                  }}
                /> : ""}
                <Icon
                  type="home"
                  style={{
                    position: "relative",
                    fontSize: "20px",
                    color: "white",
                    cursor: "pointer"
                  }}
                />
              </div>
            </Col>
            <Col span={6} offset={12}>
              <div style={{ float: "right", marginRight: 20 }}>
                <Dropdown overlay={menu}>
                  <Button>
                    Option <Icon type="down" />
                  </Button>
                </Dropdown>
              </div>
            </Col>
          </Row>
        </Header>
      </Layout>
    );
  }
}
const PageHeader = connect(mapStateToProps)(HeaderCom);
export default PageHeader;
