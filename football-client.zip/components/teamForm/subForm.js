import React, { Component } from "react";
import { Form, Button, Input, Row, Col, notification, Icon } from "antd";
import fetch from "isomorphic-unfetch";
import Router from 'next/router'

class TeamNameForm extends Component {
  state = { inputs: [] };
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        var teams = [];
        for (var i = 0; i < this.props.teams; i++) {
          teams.push({
            stt: i + 1,
            name: values["team" + i],
            brief: values["brief" + i]
          });
        }
        teams.map(t => (t.brief = t.brief.toUpperCase()));
        teams.map(t=>{
          t.mp=0;
          t.w=0;
          t.d=0;
          t.l=0;
          t.gf=0;
          t.ga=0;
          t.pts=0;
        })
        console.log(JSON.stringify(teams));
        fetch(process.env.API_HOST + "teams/list", {
          method: "post",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json"
          },
          body: JSON.stringify(teams)
        }).then(res => {
          if (res.status == 201) {
            notification.open({
              message: "Save change success",
              description: "New team list have been saved!",
              icon: <Icon type="smile" style={{ color: "#108ee9" }} />
            });
            Router.push("/")
          } else {
            notification.open({
              message: "Error occured! Status " + res.status,
              description: "There was some problem when update team list!",
              icon: <Icon type="frown" style={{ color: "#108ee9" }} />
            });
          }
        });
      } else {
        console.log("Validate error!");
      }
    });
  };
  inputKeyDown(event) {
    if (event.keyCode === 13) {
      const form = event.target.form;
      const index = Array.prototype.indexOf.call(form, event.target);
      form.elements[index + 1].focus();
      event.preventDefault();
    }
  }
  render() {
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 4 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 18 }
      }
    };

    const { getFieldDecorator } = this.props.form;
    var contains = [];
    for (var i = 0; i < this.props.teams; i++) {
      contains.push(
        <div className="input" key={i}>
          <Col span={12}>
            <Form.Item
              key={"team" + i}
              label={"Team " + (i + 1)}
              labelAlign="left"
            >
              {getFieldDecorator("team" + i, {
                rules: [{ required: true, message: "Please input team name!" }]
              })(
                <Input
                  placeholder={"Team " + (i + 1) + " name"}
                  onKeyDown={this.inputKeyDown}
                />
              )}
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item key={"brief" + i} label={"Brief name"} labelAlign="left">
              {getFieldDecorator("brief" + i, {
                rules: [{ required: true, message: "Please enter brief name!" }]
              })(
                <Input
                  placeholder={"Team " + (i + 1) + " brief name"}
                  onKeyDown={this.inputKeyDown}
                />
              )}
            </Form.Item>
          </Col>
        </div>
      );
    }
    return (
      <Form onSubmit={this.handleSubmit}>
        <Row gutter={8}>{contains}</Row>
        <Form.Item wrapperCol={{ xs: { span: 24 } }}>
          <Button type="primary" htmlType="submit">
            Save
          </Button>
        </Form.Item>
      </Form>
    );
  }
}
const SubForm = Form.create()(TeamNameForm);
export default SubForm;
