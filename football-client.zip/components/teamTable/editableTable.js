import React, { Component } from "react";
import {
  Table,
  Input,
  Button,
  Popconfirm,
  Form,
  notification,
  Icon,
  Modal
} from "antd";
import Router from "next/router";
import fetch from "isomorphic-unfetch";
import { connect } from "react-redux";
import { getTeamData, updateTable } from "../../redux/actions/actions";

const FormItem = Form.Item;
const EditableContext = React.createContext();
class EditableCell extends React.Component {
  state = {
    editing: false
  };

  toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  save = e => {
    const { record, handleSave } = this.props;
    this.form.validateFields((error, values) => {
      if (error && error[e.currentTarget.id]) {
        return;
      }
      this.toggleEdit();
      handleSave({ ...record, ...values });
    });
  };

  render() {
    const { editing } = this.state;
    const {
      editable,
      dataIndex,
      title,
      record,
      index,
      handleSave,
      ...restProps
    } = this.props;
    return (
      <td {...restProps}>
        {editable ? (
          <EditableContext.Consumer>
            {form => {
              this.form = form;
              return editing ? (
                <FormItem style={{ margin: 0 }}>
                  {form.getFieldDecorator(dataIndex, {
                    rules: [
                      {
                        required: true,
                        message: `${title} is required.`
                      }
                    ],
                    initialValue: record[dataIndex]
                  })(
                    <Input
                      ref={node => (this.input = node)}
                      onPressEnter={this.save}
                      onBlur={this.save}
                    />
                  )}
                </FormItem>
              ) : (
                <div
                  className="editable-cell-value-wrap"
                  style={{ paddingRight: 24 }}
                  onClick={this.toggleEdit}
                >
                  {restProps.children}
                </div>
              );
            }}
          </EditableContext.Consumer>
        ) : (
          restProps.children
        )}
      </td>
    );
  }
}
const EditableRow = ({ form, index, ...props }) => (
  <EditableContext.Provider value={form}>
    <tr {...props} />
  </EditableContext.Provider>
);
const EditableFormRow = Form.create()(EditableRow);

function mapStateToProps(state) {
  return {
    teams: state.teams
  };
}
function mapDispatchToProps(dispatch) {
  return {
    updateTeamTable: value => dispatch(updateTable(value)),
    getTeamData: () => dispatch(getTeamData())
  };
}
class EDTable extends Component {
  constructor(props) {
    super(props);
    this.columns = [
      {
        title: "#",
        dataIndex: "stt",
        width: "5%"
      },
      {
        title: "Name",
        dataIndex: "name",
        width: "40%",
        editable: true,
        sorter: (a, b) => a.name.toLowerCase() > b.name.toLowerCase(),
        sortDirections: ["descend", "ascend"]
      },
      {
        title: "Brief name",
        dataIndex: "brief",
        editable: true
      },
      {
        title: "Operation",
        dataIndex: "operation",
        render: (text, record) =>
          this.state.dataSource.length >= 1 ? (
            <Popconfirm
              title="Sure to delete?"
              onConfirm={() => this.handleDelete(record.key)}
            >
              <a href="javascript:;">Delete</a>
            </Popconfirm>
          ) : null
      }
    ];

    this.state = {
      dataSource: [],
      count: 0,
      dataChange: false
    };
  }

  handleDelete = key => {
    const dataSource = [...this.state.dataSource];
    this.setState({
      dataSource: dataSource.filter(item => item.key !== key),
      dataChange: true
    });
  };

  handleAdd = () => {
    const { count, dataSource } = this.state;
    const newData = {
      key: count,
      name: `Team ${count}`,
      stt: parseInt(dataSource[dataSource.length - 1].stt) + 1,
      brief: `T${count}`
    };
    this.setState({
      dataSource: [...dataSource, newData],
      count: count + 1,
      dataChange: true,
      visible: false
    });
  };

  handleSave = row => {
    const newData = [...this.state.dataSource];
    const index = newData.findIndex(item => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, {
      ...item,
      ...row
    });
    this.setState({ dataSource: newData });
  };

  submitData = () => {
    let data = this.state.dataSource;
    delete data["key"];
    data.map(t => {
      (t.brief = t.brief.toUpperCase()), (t.mp = 0);
      t.w = 0;
      t.d = 0;
      t.l = 0;
      t.gf = 0;
      t.ga = 0;
      t.pts = 0;
    });
    //teams/update
    fetch(process.env.API_HOST + "teams/list", {
      method: "post",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    }).then(res => {
      if (res.status == 201) {
        notification.open({
          message: "Save change success",
          description: "New team list have been saved!",
          icon: <Icon type="smile" style={{ color: "#108ee9" }} />
        });
      } else {
        notification.open({
          message: "Error occured! Status " + res.status,
          description: "There was some problem when update team list!",
          icon: <Icon type="frown" style={{ color: "#108ee9" }} />
        });
      }
    });
  };

  componentDidMount() {
    this.props.getTeamData();
    this.setState({ dataSource: this.props.teams, count: this.props.teams.length });
  }

  showModal = () => {
    this.setState({
      visible: true
    });
  };

  showModal2 = () => {
    this.setState({
      visible2: true
    });
  };

  handleOk = e => {
    this.setState({
      visible: false
    });
    fetch(process.env.API_HOST + "teams", { method: "delete" })
      .then(res => {
        if (res.status == 200) {
          notification.open({
            message: "League is deleted",
            description: "You can create new league now!",
            icon: <Icon type="smile" style={{ color: "#108ee9" }} />
          });
          Router.push("/");
        } else {
          notification.open({
            message: "Error occured! Status " + res.status,
            description: "There was some problem when deleting league!",
            icon: <Icon type="frown" style={{ color: "#108ee9" }} />
          });
        }
      })
      .catch(err => {
        console.log(err);
      });
  };

  handleOk2 = e => {
    this.submitData();
    this.setState({
      visible2: false
    });
  };

  handleCancel = e => {
    this.setState({
      visible: false
    });
  };

  handleCancel2 = e => {
    this.setState({
      visible2: false
    });
  };

  render() {
    const components = {
      body: {
        row: EditableFormRow,
        cell: EditableCell
      }
    };
    const columns = this.columns.map(col => {
      if (!col.editable) {
        return col;
      }
      return {
        ...col,
        onCell: record => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleSave
        })
      };
    });
    return (
      <div>
        <Button
          onClick={this.handleAdd}
          type="primary"
          style={{ margin: "10px 0px" }}
        >
          Add new team
        </Button>
        <Button
          onClick={this.showModal}
          style={{
            margin: "10px 5px",
            background: "#dc3545",
            borderColor: "#dc3545",
            color: "white"
          }}
        >
          Delete league
        </Button>
        <Modal
          title="Delete Confirm"
          visible={this.state.visible}
          onOk={this.handleOk}
          onCancel={this.handleCancel}
        >
          <p>Are you sure to delete this league?</p>
        </Modal>
        <Modal
          title="Update Confirm"
          visible={this.state.visible2}
          onOk={this.handleOk2}
          onCancel={this.handleCancel2}
        >
          <p>This will override your league old data. Are you sure?</p>
        </Modal>
        <div>
          <p>*Tips: You can click on table cell to edit it!</p>
        </div>
        <Table
          components={components}
          rowClassName={() => "editable-row"}
          bordered
          dataSource={this.state.dataSource}
          //dataSource={this.props.teams}
          columns={columns}
          pagination={{ defaultPageSize: 10 }}
        />
        {this.state.dataChange ? (
          <Button
            onClick={this.showModal2}
            type="primary"
            style={{ background: "#28a745" }}
          >
            Save change
          </Button>
        ) : (
          ""
        )}
      </div>
    );
  }
}
const EditableTable = connect(
  mapStateToProps,
  mapDispatchToProps
)(EDTable);
export default EditableTable;
