import React, { Component } from "react";
import EditableTable from "./editableTable";
export class TeamTable extends Component {
  state = {
    dataSource: [],
    count: 0
  };

  render() {    
    return <EditableTable/>;
  }
}
