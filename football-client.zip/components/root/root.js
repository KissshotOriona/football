import PageHeader from "../header/header";
import { SideMenu } from "../sideMenu/sideMenu";
import { Layout, Col, Row } from "antd";
const { Header } = Layout;
import { Provider } from "react-redux";
import store from "../../redux/store/store";
import './root.css';

export default function Root(props) {
  return (
    <Provider store={store}>
      <div>
        <Layout>
          <Header style={{ background: "#58a700", padding: 0 }}>
            <PageHeader />
          </Header>
          <Layout>
            <Row
              type="flex"
              gutter={8}
              style={{  borderBottom: "1px solid #bfbfbf" }}
            >
              <Col
                xs={24}
                sm={8}
                md={6}
                lg={5}
                className="sidemenu"
                style={{
                  position: "fixed",
                  height: "inherit"
                }}
              >
                <SideMenu />
              </Col>
              <Col
                xs={24}
                md={{ span: 18, offset: 6 }}
                lg={{ span: 19, offset: 5 }}
                style={{
                  paddingLeft: "10px",
                  paddingRight: "10px",
                  borderLeft: "1px solid #bfbfbf",
                  textAlign: "center",
                  paddingBottom: "10px",
                  minHeight: "145px"
                }}
              >
                {props.children}
              </Col>
            </Row>
          </Layout>
        </Layout>
      </div>
    </Provider>
  );
}
