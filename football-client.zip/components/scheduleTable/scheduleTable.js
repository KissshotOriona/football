import { Table } from "antd";
import React, { Component } from "react";
import fetch from "isomorphic-unfetch";
import MatchForm from "./matchForm";
import { connect } from "react-redux";
import { getMatchData } from "../../redux/actions/actions";

const columns = [
  { title: "#", dataIndex: "stt", key: "name", align: "center" },
  { title: "Team 1", dataIndex: "team.t1", key: "t1", align: "center" },
  { title: "Result", dataIndex: "res", key: "res", align: "center" },
  { title: "Team 2", dataIndex: "team.t2", key: "t2", align: "center" },
  { title: "Date", dataIndex: "date", key: "date", align: "center" },
  { title: "Time", dataIndex: "time", key: "time", align: "center" }
];

function mapStateToProps(state) {
  return {
    matchs: state.matchs
  };
}
class Schedule extends Component {
  state = {
  };
  constructor(props) {
    super(props);
    this.changeState = this.changeState.bind(this);
  }
  componentDidMount() {
    this.props.getMatchData();
  }
  changeState(res, index) {
    var sta = this.state.data;
    console.log(index);
    sta[index - 1].res = res;
    this.setState({ data: sta });
  }
  render() {
    const matchs = this.props.matchs;
    console.log(matchs);
    matchs.map((e, index) => {
      e.stt = index + 1;
      e.res = e.goal.g1 + " - " + e.goal.g2;
    });
    return (
      <div>
        <div style={{ marginTop: "10px" }}>
          <p>
            {matchs.length > 0
              ? "*Tips: Click toggle button to update match info!"
              : "*You need to create a league first!"}
          </p>
        </div>
        <Table
          scroll={{ x: 40 }}
          bordered
          columns={columns}
          expandedRowRender={record => (
            <MatchForm
              handler={this.changeState}
              data={matchs}
              record={record}
            />
          )}
          dataSource={matchs}
        />
        ,
      </div>
    );
  }
}
const ScheduleTable = connect(
  mapStateToProps,
  { getMatchData }
)(Schedule);
export default ScheduleTable;
