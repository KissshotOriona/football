import React, { Component } from "react";
import { Menu, Icon } from "antd";
import Router from "next/router";
import './sideMenu.css'

export class SideMenu extends Component {
  state = {
    selected: "1",
    menuMode: "inline"
  };
  menuClick(e) {
    if (e.key == 1) {
      Router.push("/");
    } else {
      if (e.key == 2) {
        Router.push("/schedule");
      } else {
        Router.push("/standing");
      }
    }
  }
  
  getSelectItem() {
    if (typeof window === "object") {
      var ref = window.location.href.split("/");
      var tab = ref[ref.length - 1];
      if (tab == "schedule") {
        return "2";
      } else {
        if (tab == "standing") {
          return "3";
        } else {
          return "1";
        }
      }
    }else{
    }
  }

  transformOnResize() {
    if (window.innerWidth < 767) {
      this.setState({
        menuMode: "horizontal"
      });
    } else {
      this.setState({
        menuMode: "inline"
      });
    }
  }

  componentDidMount() {
    this.transformOnResize();
    window.addEventListener("resize", this.transformOnResize.bind(this));
  }

  render() {
    return (
      <Menu
        defaultSelectedKeys={[this.getSelectItem()]}
        defaultOpenKeys={["sub1"]}
        mode={this.state.menuMode}
        inlineCollapsed={this.state.collapsed}
      >
        <Menu.Item key="1" onClick={this.menuClick}>
          <Icon type="deployment-unit" />
          <span>League</span>
        </Menu.Item>
        <Menu.Item key="2" onClick={this.menuClick}>
          <Icon type="apartment" />
          <span>Match schedule</span>
        </Menu.Item>
        <Menu.Item key="3" onClick={this.menuClick}>
          <Icon type="trophy" />
          <span>Standing</span>
        </Menu.Item>
      </Menu>
    );
  }
}
